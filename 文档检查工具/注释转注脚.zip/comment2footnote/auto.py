#-*-coding:UTF-8 -*- 

import os,sys,traceback
import delfootnote,comment2footnote,delcomment


src = "src.doc"

lstCommentText = []
lstScopeText = []
		
def main ():
	print "-"*80
	srcfile = src
	destfile = srcfile[0:srcfile.rfind('.')] + "_result.doc"
	if(len(sys.argv)>1):
		srcfile =  sys.argv[1]
	if(len(sys.argv)>2):
		destfile =  sys.argv[2]
	else:
		destfile = srcfile[0:srcfile.rfind('.')] + "_result.doc"
	srcfile = os.path.realpath(srcfile)
	destfile = os.path.realpath(destfile)
	if(False == os.path.exists(srcfile)):
		print ('源文件不存在： %s'%(srcfile)).decode("UTF-8").encode("cp936")
		return
	"""
	if(False == os.path.exists(destfile)):
		print ('目的文件不存在： %s'%(destfile)).decode("UTF-8").encode("cp936")
		return
	"""
	print ("源文件:%s"%(srcfile)).decode("UTF-8").encode("cp936")
	print ("目的文件:%s"%(destfile)).decode("UTF-8").encode("cp936")
	print 
	delfootnote.delfootnote(srcfile,srcfile+".1.doc")
	print 
	comment2footnote.comment2footnote(srcfile+".1.doc",srcfile+".2.doc")
	print 
	delcomment.delcomment(srcfile+".2.doc",destfile)
	print "-"*80

if __name__ == "__main__":
	main()
	
	
    
                                         
