#-*-coding:UTF-8 -*- 

import os,sys,traceback
from win32com.client import DispatchEx,Dispatch


src = "src.doc"

lstCommentText = []
lstScopeText = []

def comment2footnote (srcfile,destfile):
	app = None
	doc = None
	try:
		#print "app = DispatchEx('Word.Application') 开始 ...".decode("UTF-8").encode("cp936")
		app = DispatchEx("Word.Application")
		#print "app = DispatchEx('Word.Application') 完成 ".decode("UTF-8").encode("cp936")
		
		#print ("doc = app.Documents.Open('%s') 开始..."%(srcfile)).decode("UTF-8").encode("cp936")
		doc = app.Documents.Open(srcfile)
		#print ("doc = app.Documents.Open('%s') 完成"%(srcfile)).decode("UTF-8").encode("cp936")
		
		count = doc.Comments.Count

		print "遍历批注,生成脚注，开始 ...".decode("UTF-8").encode("cp936")
		
		print '进度 ... '.decode("UTF-8").encode("cp936"),0,'/',count,
		i = 0
		for commonet in doc.Comments:
			try:
				i = i + 1
				print '\r',
				print '进度 ... '.decode("UTF-8").encode("cp936"),i,'/',count,
				
				#lstCommentText.append(commonet.Range.Text)
				#lstScopeText.append(commonet.Scope.Text)
				#print "批注".decode("UTF-8").encode("cp936"),commonet.Range.Text.encode("cp936")
				#print "内容".decode("UTF-8").encode("cp936"),commonet.Scope.Text.encode("cp936")
				
				commonet.Scope.FootnoteOptions.Location=0
				#NumberingRule=0：整个文件一个开始编号，1：每页开始编号
				#commonet.Scope.FootnoteOptions.NumberingRule=1
				commonet.Scope.FootnoteOptions.NumberingRule=0
				commonet.Scope.FootnoteOptions.StartingNumber=1
				commonet.Scope.FootnoteOptions.NumberStyle=0
				text = "[" + commonet.Scope.Text + "] " + commonet.Range.Text
				commonet.Scope.Footnotes.Add(Range=commonet.Scope, Reference="",Text=text)
				#commonet.Delete()
								  
		  
			except:
				print sys.exc_info()
				raise

		print ''
		print "遍历批注,生成脚注，完成".decode("UTF-8").encode("cp936")
		if(os.path.exists(destfile)):
			#print ("目的文件已经村子啊，正在删除原有文件:%s"%(destfile)).decode("UTF-8").encode("cp936")
			os.remove(destfile)
		
		#print ("保存目的文件:%s 开始 ..."%(destfile)).decode("UTF-8").encode("cp936")
		doc.SaveAs(destfile)
		#print ("保存目的文件:%s 完成"%(destfile)).decode("UTF-8").encode("cp936")

		#print ("关闭文件:%s 开始 ..."%(destfile)).decode("UTF-8").encode("cp936")
		doc.Close()
		doc = None
		#print ("关闭文件:%s 完成"%(destfile)).decode("UTF-8").encode("cp936")

		#print ("关闭Word 开始 ...").decode("UTF-8").encode("cp936")
		app.Quit()
		app = None
		#print ("关闭Word 完成").decode("UTF-8").encode("cp936")

		
		#print "程序成功完成".decode("UTF-8").encode("cp936")

	except:
		print ''
		print sys.exc_info()
	finally:
		if(doc):
			doc.Close()
		if(app):
			app.Quit()

def main ():
	print "-"*80
	srcfile = src
	destfile = srcfile[0:srcfile.rfind('.')] + "_result.doc"
	if(len(sys.argv)>1):
		srcfile =  sys.argv[1]
	if(len(sys.argv)>2):
		destfile =  sys.argv[2]
	else:
		destfile = srcfile[0:srcfile.rfind('.')] + "_result.doc"
	srcfile = os.path.realpath(srcfile)
	destfile = os.path.realpath(destfile)
	if(False == os.path.exists(srcfile)):
		print ('源文件不存在： %s'%(srcfile)).decode("UTF-8").encode("cp936")
		return
	"""
	if(False == os.path.exists(destfile)):
		print ('目的文件不存在： %s'%(destfile)).decode("UTF-8").encode("cp936")
		return
	"""
	print ("源文件:%s..........."%(srcfile)).decode("UTF-8").encode("cp936")
	print ("目的文件:%s..........."%(destfile)).decode("UTF-8").encode("cp936")
	print 
	comment2footnote(srcfile,destfile)
	print "-"*80

if __name__ == "__main__":
	main()
	
    
                                         
